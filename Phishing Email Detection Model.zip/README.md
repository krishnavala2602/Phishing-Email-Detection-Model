# Phishing Email Detection Model

A Scikit-learn pipeline that classifies emails as **Phishing** or **Safe**
using a combination of text features (TF-IDF over subject + body) and
hand-crafted URL/keyword features.

## Files

| File | Purpose |
|---|---|
| `generate_dataset.py` | Builds a labeled synthetic dataset (`emails.csv`) of phishing & legitimate emails. Swap this out for a real dataset (see below). |
| `features.py` | Extracts structured features: URL count, IP-based URLs, link shorteners, suspicious TLDs, phishing keyword counts, sender-domain heuristics, etc. Combines them with TF-IDF text features. |
| `train_model.py` | Trains Logistic Regression and Random Forest models, prints accuracy/precision/recall/F1/ROC-AUC, saves a confusion matrix, ROC curve, and feature-importance chart, and pickles the best model to `model.joblib`. |
| `predict.py` | CLI tool to classify a new email using the saved model. |

## Quick start

```bash
pip install scikit-learn pandas numpy matplotlib seaborn joblib

python generate_dataset.py      # creates emails.csv (300 phishing + 300 safe)
python train_model.py           # trains, evaluates, saves model.joblib + charts
python predict.py --subject "Verify your account" \
                   --sender "support@paypa1-secure.com" \
                   --body "Click here http://192.168.1.5/login to verify now"
```

Or interactively:
```bash
python predict.py --interactive
```

## How it works

**Text signal (TF-IDF, 1–2 grams, top 3000 terms)**
Captures phishing-style language: "verify your account", "click here",
"suspended", "urgent", "act now", etc., versus everyday conversational
language in legitimate emails.

**Structured signal** (`features.py`):
- Number of URLs in the email
- Whether any URL uses a raw IP address instead of a domain
- Whether any URL uses a known shortener (bit.ly, tinyurl, etc.)
- Whether any URL domain uses a suspicious TLD (.xyz, .click, .top, ...)
- Count of phishing-associated keywords (verify, urgent, suspended, refund, ...)
- Email length, exclamation-mark count, ALL-CAPS word count
- Sender-domain heuristics (lookalike domains like `paypa1`, `amaz0n`, excess hyphens)

These are scaled with `StandardScaler` and combined with the sparse TF-IDF
matrix via `scipy.sparse.hstack`, then fed into a single classifier.

## Models compared

- **Logistic Regression** (`class_weight="balanced"`) — fast, interpretable,
  coefficients directly show which words/features push toward "Phishing."
- **Random Forest** (300 trees, `class_weight="balanced"`) — captures
  non-linear feature interactions.

`train_model.py` trains both and saves whichever scores higher on F1.

## Outputs

- `confusion_matrix.png` — true vs. predicted labels on the held-out test set
- `roc_curve.png` — ROC curve with AUC
- `feature_importance.png` — top 20 features driving predictions (red = pushes
  toward Phishing, blue = pushes toward Safe)
- `model.joblib` — serialized `{clf, tfidf, scaler}` bundle for reuse in `predict.py`

## A note on accuracy and the demo dataset

The bundled `generate_dataset.py` produces synthetic emails from template
patterns, so the demo model scores very highly (often ~100%) on the held-out
split — that mainly confirms the **pipeline** (feature extraction → training →
evaluation → inference) is wired correctly end-to-end, not that it would hit
that score on real-world inboxes.

For a production-grade or coursework-grade model, swap `emails.csv` for a
real public dataset, for example:
- Kaggle "Phishing Email Dataset"
- The Nazario phishing corpus + Enron legitimate-email corpus
- SpamAssassin public corpus (legitimate side)

Just keep the same column schema (`subject, sender, body, label`) and
`train_model.py` / `predict.py` will work unchanged. Expect accuracy in the
90–97% range on a realistic, more diverse dataset, with the confusion matrix
revealing the harder cases (well-crafted spear-phishing emails with few
obvious keyword/URL red flags).
