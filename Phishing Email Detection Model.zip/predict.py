"""
predict.py
-----------
Load the trained model (model.joblib) and classify new email(s).

Usage examples:
    python predict.py --subject "Verify your account" --sender "x@paypa1-secure.com" --body "Click here http://192.168.1.5/login to verify now"

    python predict.py --interactive
"""

import argparse
import joblib
import pandas as pd

from features import build_feature_matrix


def load_model(path="model.joblib"):
    bundle = joblib.load(path)
    return bundle["clf"], bundle["tfidf"], bundle["scaler"]


def classify(subject: str, sender: str, body: str, clf, tfidf, scaler):
    df = pd.DataFrame([{"subject": subject, "sender": sender, "body": body}])
    X, _ = build_feature_matrix(df, tfidf, scaler, fit=False)
    pred = clf.predict(X)[0]
    proba = clf.predict_proba(X)[0][1]  # probability of "Phishing"
    label = "Phishing" if pred == 1 else "Safe"
    return label, proba


def main():
    parser = argparse.ArgumentParser(description="Classify an email as Phishing or Safe.")
    parser.add_argument("--subject", type=str, default="")
    parser.add_argument("--sender", type=str, default="")
    parser.add_argument("--body", type=str, default="")
    parser.add_argument("--interactive", action="store_true", help="Prompt for input interactively")
    args = parser.parse_args()

    clf, tfidf, scaler = load_model()

    if args.interactive:
        subject = input("Subject: ")
        sender = input("Sender:  ")
        body = input("Body:    ")
    else:
        subject, sender, body = args.subject, args.sender, args.body

    if not (subject or sender or body):
        print("No input provided. Use --subject/--sender/--body or --interactive.")
        return

    label, proba = classify(subject, sender, body, clf, tfidf, scaler)
    print(f"\nPrediction: {label}")
    print(f"Phishing probability: {proba:.2%}")


if __name__ == "__main__":
    main()
