"""
features.py
------------
Feature engineering for phishing email detection.

Combines two kinds of signal:
1. TEXT features  -> TF-IDF over subject + body (captures phishing language
   like "verify", "urgent", "suspended", "click here", etc.)
2. STRUCTURED features -> hand-crafted numeric/boolean features about URLs,
   sender address, punctuation, and known phishing keywords.

The structured features are scaled and combined with the TF-IDF sparse
matrix via scipy.sparse.hstack so a single classifier can use both.
"""

import re
import numpy as np
import pandas as pd
from scipy.sparse import hstack, csr_matrix

# Common urgency / credential-harvesting keywords seen in phishing emails
PHISHING_KEYWORDS = [
    "verify", "urgent", "suspend", "suspended", "click here", "confirm",
    "update your", "account", "password", "security alert", "limited",
    "act now", "immediately", "expire", "winner", "congratulations",
    "claim", "free", "gift card", "bank", "login", "credentials",
    "ssn", "social security", "billing", "invoice overdue", "refund",
    "locked", "reactivate", "unusual activity", "final notice",
]

URL_REGEX = re.compile(r"https?://[^\s]+")
IP_URL_REGEX = re.compile(r"https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")
SHORTENER_DOMAINS = ["bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly", "is.gd"]

# Suspicious-but-plausible-looking domain tricks: digits replacing letters,
# extra hyphens, etc. We approximate with a few simple heuristics rather
# than a full domain-reputation lookup.
SUSPICIOUS_TLDS = [".xyz", ".click", ".info", ".top", ".club", ".online"]


def _extract_urls(text: str):
    return URL_REGEX.findall(text or "")


def _count_keywords(text: str) -> int:
    text_lower = (text or "").lower()
    return sum(text_lower.count(kw) for kw in PHISHING_KEYWORDS)


def _sender_domain_suspicious(sender: str) -> int:
    """Cheap heuristic: lots of hyphens, digits substituted for letters,
    or a suspicious TLD in the sender's domain."""
    if not sender or "@" not in sender:
        return 0
    domain = sender.split("@")[-1].lower()
    score = 0
    if domain.count("-") >= 2:
        score += 1
    if re.search(r"[0-9]", domain.split(".")[0]):
        score += 1  # e.g. paypa1, amaz0n
    if any(domain.endswith(tld) for tld in SUSPICIOUS_TLDS):
        score += 1
    return 1 if score >= 1 else 0


def extract_structured_features(df: pd.DataFrame) -> pd.DataFrame:
    """Given a DataFrame with columns subject, sender, body, return a
    DataFrame of numeric structured features (one row per email)."""
    feats = pd.DataFrame(index=df.index)

    full_text = (df["subject"].fillna("") + " " + df["body"].fillna(""))

    urls_per_email = full_text.apply(_extract_urls)

    feats["num_urls"] = urls_per_email.apply(len)
    feats["has_ip_url"] = full_text.apply(lambda t: 1 if IP_URL_REGEX.search(t or "") else 0)
    feats["has_shortened_url"] = urls_per_email.apply(
        lambda urls: 1 if any(any(s in u for s in SHORTENER_DOMAINS) for u in urls) else 0
    )
    feats["has_suspicious_tld"] = urls_per_email.apply(
        lambda urls: 1 if any(any(u.lower().split("/")[2].endswith(tld) if len(u.split("/")) > 2 else False
                                   for tld in SUSPICIOUS_TLDS) for u in urls) else 0
    )
    feats["keyword_count"] = full_text.apply(_count_keywords)
    feats["text_length"] = full_text.apply(len)
    feats["exclamation_count"] = full_text.apply(lambda t: (t or "").count("!"))
    feats["uppercase_word_count"] = full_text.apply(
        lambda t: sum(1 for w in (t or "").split() if len(w) > 2 and w.isupper())
    )
    feats["sender_domain_suspicious"] = df["sender"].apply(_sender_domain_suspicious)
    feats["subject_has_urgent_word"] = df["subject"].fillna("").apply(
        lambda s: 1 if re.search(r"urgent|alert|suspend|verify|action required|final notice", s.lower()) else 0
    )

    return feats


def build_feature_matrix(df: pd.DataFrame, tfidf_vectorizer, scaler, fit=False):
    """
    Combine TF-IDF text features with scaled structured features.

    Parameters
    ----------
    df : DataFrame with subject, sender, body columns
    tfidf_vectorizer : a fitted or unfitted TfidfVectorizer
    scaler : a fitted or unfitted StandardScaler (with_mean=False friendly)
    fit : if True, fit the vectorizer/scaler on this data; else transform only

    Returns
    -------
    X : sparse feature matrix (n_samples, n_features)
    """
    full_text = (df["subject"].fillna("") + " " + df["body"].fillna(""))

    if fit:
        text_matrix = tfidf_vectorizer.fit_transform(full_text)
    else:
        text_matrix = tfidf_vectorizer.transform(full_text)

    structured = extract_structured_features(df)

    if fit:
        structured_scaled = scaler.fit_transform(structured.values)
    else:
        structured_scaled = scaler.transform(structured.values)

    X = hstack([text_matrix, csr_matrix(structured_scaled)]).tocsr()
    return X, structured.columns.tolist()
