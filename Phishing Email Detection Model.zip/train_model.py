"""
train_model.py
----------------
Trains a phishing-email classifier and evaluates it.

Usage:
    python train_model.py [path_to_csv]

If no CSV path is given, it looks for emails.csv in the current directory
(run generate_dataset.py first if it doesn't exist).

CSV must have columns: subject, sender, body, label (1=Phishing, 0=Safe)

Outputs:
    - Printed accuracy, precision, recall, F1, classification report
    - confusion_matrix.png
    - feature_importance.png (top TF-IDF / structured features)
    - model.joblib (saved pipeline: vectorizer + scaler + classifier)
"""

import sys
import os
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # headless rendering
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score, roc_curve
)

from features import build_feature_matrix, PHISHING_KEYWORDS

RANDOM_STATE = 42


def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"subject", "sender", "body", "label"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"CSV is missing required columns: {missing}")
    df = df.dropna(subset=["label"]).copy()
    df["label"] = df["label"].astype(int)
    return df


def train_and_evaluate(df: pd.DataFrame, model_choice: str = "logreg"):
    X_train_df, X_test_df, y_train, y_test = train_test_split(
        df[["subject", "sender", "body"]],
        df["label"],
        test_size=0.25,
        random_state=RANDOM_STATE,
        stratify=df["label"],
    )

    tfidf = TfidfVectorizer(
        max_features=3000,
        ngram_range=(1, 2),
        stop_words="english",
        sublinear_tf=True,
    )
    scaler = StandardScaler(with_mean=False)  # sparse-friendly

    X_train, struct_cols = build_feature_matrix(X_train_df, tfidf, scaler, fit=True)
    X_test, _ = build_feature_matrix(X_test_df, tfidf, scaler, fit=False)

    if model_choice == "rf":
        clf = RandomForestClassifier(
            n_estimators=300, random_state=RANDOM_STATE, class_weight="balanced", n_jobs=-1
        )
    else:
        clf = LogisticRegression(
            max_iter=1000, class_weight="balanced", random_state=RANDOM_STATE
        )

    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    y_proba = clf.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1": f1_score(y_test, y_pred),
        "roc_auc": roc_auc_score(y_test, y_proba),
    }

    cm = confusion_matrix(y_test, y_pred)
    report = classification_report(y_test, y_pred, target_names=["Safe", "Phishing"])

    return {
        "clf": clf,
        "tfidf": tfidf,
        "scaler": scaler,
        "struct_cols": struct_cols,
        "metrics": metrics,
        "confusion_matrix": cm,
        "report": report,
        "y_test": y_test,
        "y_pred": y_pred,
        "y_proba": y_proba,
    }


def plot_confusion_matrix(cm, out_path="confusion_matrix.png"):
    plt.figure(figsize=(5.5, 4.5))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues", cbar=False,
        xticklabels=["Safe", "Phishing"], yticklabels=["Safe", "Phishing"]
    )
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.title("Confusion Matrix - Phishing Email Detection")
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()


def plot_roc(y_test, y_proba, roc_auc, out_path="roc_curve.png"):
    fpr, tpr, _ = roc_curve(y_test, y_proba)
    plt.figure(figsize=(5.5, 4.5))
    plt.plot(fpr, tpr, label=f"ROC curve (AUC = {roc_auc:.3f})", linewidth=2)
    plt.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Random guess")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve")
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()


def plot_feature_importance(clf, tfidf, struct_cols, out_path="feature_importance.png", top_n=20):
    feature_names = np.array(tfidf.get_feature_names_out().tolist() + struct_cols)

    if hasattr(clf, "coef_"):
        importances = clf.coef_[0]
    elif hasattr(clf, "feature_importances_"):
        importances = clf.feature_importances_
    else:
        return  # nothing to plot

    top_idx = np.argsort(np.abs(importances))[-top_n:]
    top_features = feature_names[top_idx]
    top_values = importances[top_idx]

    colors = ["#d62728" if v > 0 else "#1f77b4" for v in top_values]

    plt.figure(figsize=(8, 7))
    plt.barh(range(len(top_idx)), top_values, color=colors)
    plt.yticks(range(len(top_idx)), top_features)
    plt.xlabel("Importance (red = pushes toward Phishing)")
    plt.title(f"Top {top_n} Most Influential Features")
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()


def main():
    csv_path = sys.argv[1] if len(sys.argv) > 1 else "emails.csv"
    if not os.path.exists(csv_path):
        print(f"'{csv_path}' not found. Run 'python generate_dataset.py' first, "
              f"or pass the path to your own CSV (columns: subject, sender, body, label).")
        sys.exit(1)

    print(f"Loading dataset from {csv_path} ...")
    df = load_data(csv_path)
    print(f"Loaded {len(df)} emails  |  Phishing: {(df['label']==1).sum()}  Safe: {(df['label']==0).sum()}")

    print("\nTraining model (Logistic Regression) ...")
    result = train_and_evaluate(df, model_choice="logreg")

    m = result["metrics"]
    print("\n=== Evaluation Metrics (Logistic Regression) ===")
    print(f"Accuracy : {m['accuracy']:.4f}")
    print(f"Precision: {m['precision']:.4f}")
    print(f"Recall   : {m['recall']:.4f}")
    print(f"F1 Score : {m['f1']:.4f}")
    print(f"ROC AUC  : {m['roc_auc']:.4f}")
    print("\nConfusion Matrix [rows=true, cols=pred] (order: Safe, Phishing):")
    print(result["confusion_matrix"])
    print("\nClassification Report:")
    print(result["report"])

    plot_confusion_matrix(result["confusion_matrix"])
    plot_roc(result["y_test"], result["y_proba"], m["roc_auc"])
    plot_feature_importance(result["clf"], result["tfidf"], result["struct_cols"])

    # Also train a Random Forest for comparison
    print("\nTraining comparison model (Random Forest) ...")
    rf_result = train_and_evaluate(df, model_choice="rf")
    rf_m = rf_result["metrics"]
    print(f"Random Forest -> Accuracy: {rf_m['accuracy']:.4f}  F1: {rf_m['f1']:.4f}  ROC AUC: {rf_m['roc_auc']:.4f}")

    # Save the better-performing model (by F1) as the deployed model
    best = result if m["f1"] >= rf_m["f1"] else rf_result
    best_name = "Logistic Regression" if best is result else "Random Forest"
    print(f"\nSaving best model ({best_name}) to model.joblib ...")

    joblib.dump({
        "clf": best["clf"],
        "tfidf": best["tfidf"],
        "scaler": best["scaler"],
    }, "model.joblib")

    print("\nDone. Generated files: confusion_matrix.png, roc_curve.png, feature_importance.png, model.joblib")


if __name__ == "__main__":
    main()
