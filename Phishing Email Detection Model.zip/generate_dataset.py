"""
generate_dataset.py
--------------------
Generates a labeled dataset of phishing and legitimate emails and saves it
to emails.csv. In a real project you'd replace this with a public dataset
(e.g. Kaggle's "Phishing Email Dataset" or Nazario's phishing corpus), but
this generator produces realistic, varied text so the full pipeline
(features -> model -> evaluation) can be demonstrated and tested end to end.

Each row: subject, body, sender, label (1 = Phishing, 0 = Safe)
"""

import random
import csv

random.seed(42)

# ---------------------------------------------------------------------------
# Building blocks for PHISHING emails
# ---------------------------------------------------------------------------

phishing_subjects = [
    "Urgent: Your Account Will Be Suspended",
    "Action Required: Verify Your Account Now",
    "Security Alert - Unusual Sign-in Activity Detected",
    "Your Payment Could Not Be Processed",
    "You Have Won a Prize! Claim Now",
    "Final Notice: Update Your Billing Information",
    "Your Account Has Been Limited",
    "Confirm Your Identity to Avoid Suspension",
    "Re: Invoice Overdue - Immediate Action Needed",
    "Your Package Could Not Be Delivered",
    "IT Helpdesk: Password Expires Today",
    "Important: Tax Refund Pending Approval",
    "Your Subscription Has Been Cancelled",
    "Unusual Login Attempt From New Device",
    "Verify Your Email to Continue Using Your Account",
    "Congratulations! You've Been Selected",
    "Your PayPal Account Is Limited",
    "Bank Alert: Suspicious Transaction Detected",
    "Apple ID Locked - Verify Now",
    "Netflix Payment Failed - Update Now",
]

phishing_senders = [
    "security-alert@paypa1-support.com",
    "no-reply@account-verify-secure.net",
    "support@appleid-confirm.com",
    "billing@netfllix-update.com",
    "admin@bankofamerica-secure-login.com",
    "service@amaz0n-update.com",
    "helpdesk@it-supportdesk.info",
    "notification@microsoft-security-alert.com",
    "alerts@chase-online-verify.com",
    "team@dropbox-fileshare-secure.net",
]

phishing_bodies = [
    "Dear Customer, we detected unusual activity on your account. Click here {url} immediately to verify your identity or your account will be suspended within 24 hours.",
    "Your account has been temporarily limited due to suspicious activity. Please confirm your information by clicking the link below: {url}. Failure to act within 48 hours will result in permanent suspension.",
    "We were unable to process your most recent payment. To avoid service interruption, please update your billing details now at {url}. Act now to avoid losing access.",
    "Congratulations! You have been selected to receive a $1000 gift card. Click {url} now to claim your prize before it expires. Limited time offer!",
    "This is an urgent message from our security team. We noticed a login attempt from an unrecognized device. If this wasn't you, verify your account immediately at {url}.",
    "Your package delivery failed due to an incomplete address. Click {url} to reschedule delivery and pay a small redelivery fee of $2.99 using your card details.",
    "Dear user, your password will expire today. To keep using your account, please reset your password immediately by visiting {url} and entering your current credentials.",
    "Final reminder: your invoice #4471 is overdue. Click {url} now to make a payment and avoid additional late fees and legal action.",
    "We have detected that your mailbox has exceeded its storage limit. Click {url} to verify your account and increase your storage immediately, or your account will be closed.",
    "Your Apple ID has been locked for security reasons. Verify your identity now at {url} to restore full access. This link will expire in 1 hour.",
    "Tax refund notice: You are eligible for a refund of $824.50. Submit your bank details at {url} within 72 hours to receive your refund.",
    "Act now! Your subscription was cancelled due to a billing issue. Update your payment method immediately at {url} to restore service without interruption.",
]

phishing_urls = [
    "http://192.168.45.22/verify-account",
    "http://paypa1-secure-login.com/update",
    "http://bit.ly/3xK9zT",
    "http://appleid-confirm-now.net/login",
    "http://secure-bankofamerica.info/verify",
    "http://account-update-now.xyz/confirm",
    "http://tinyurl.com/y8zqv3w2",
    "http://netfllix-billing.com/update-payment",
    "http://192.0.2.55/secure/login.php",
    "http://verify-now-account.click/login",
]

# ---------------------------------------------------------------------------
# Building blocks for LEGITIMATE emails
# ---------------------------------------------------------------------------

legit_subjects = [
    "Team Meeting Rescheduled to 3 PM",
    "Q3 Project Report Attached",
    "Lunch Tomorrow?",
    "Your Order Has Shipped",
    "Weekly Newsletter - Company Updates",
    "Reminder: Doctor's Appointment Friday",
    "Notes From Today's Standup",
    "Invoice for Your Recent Purchase",
    "Welcome to the Team!",
    "Your Flight Itinerary for Next Week",
    "Happy Birthday!",
    "Draft Proposal for Review",
    "Conference Registration Confirmation",
    "Photos From the Weekend Trip",
    "Update on the Marketing Campaign",
    "Your Monthly Statement Is Ready",
    "Question About the Budget Spreadsheet",
    "Thanks for Your Help Yesterday",
    "Schedule for Next Week's Workshop",
    "Quick Follow-up on Our Call",
]

legit_senders = [
    "john.smith@company.com",
    "newsletter@nytimes.com",
    "no-reply@github.com",
    "orders@amazon.com",
    "hr@company.com",
    "calendar-notification@google.com",
    "support@spotify.com",
    "billing@adobe.com",
    "team@slack.com",
    "alerts@chase.com",
    "events@eventbrite.com",
    "notifications@linkedin.com",
]

legit_bodies = [
    "Hi team, just a reminder that our meeting has been moved to 3 PM today in conference room B. Let me know if that doesn't work for you.",
    "Hello, please find attached the Q3 project report we discussed last week. Let me know if you have any questions before the review meeting.",
    "Hey, are you free for lunch tomorrow around noon? I was thinking we could try the new place downtown.",
    "Good news! Your order #58291 has shipped and is expected to arrive on Thursday. You can track it using the link in your account dashboard.",
    "Here is our weekly newsletter with updates from across the company, including the new product launch and upcoming holiday schedule.",
    "This is a reminder that you have a doctor's appointment this Friday at 10 AM. Please arrive 15 minutes early to complete paperwork.",
    "Hi all, here are the notes from today's standup. We discussed the sprint progress and decided to push the release date by two days.",
    "Thank you for your recent purchase. Your invoice is attached for your records. Please reach out if you have any billing questions.",
    "Welcome aboard! We're excited to have you join the team starting Monday. Your manager will send over the onboarding schedule shortly.",
    "Attached is your flight itinerary for next week's trip to Chicago. Please review the details and let us know if anything needs to change.",
    "Happy birthday! Hope you have a wonderful day filled with cake and good company. See you at the office party later.",
    "Hi, I've attached the draft proposal for the new client project. Could you review it and send feedback by end of day Friday?",
    "Thank you for registering for the annual conference. Your badge and schedule are attached. We look forward to seeing you there.",
    "Hey, I uploaded the photos from our weekend trip to the shared drive. Let me know which ones you'd like printed.",
    "Quick update on the marketing campaign: open rates are up 12% this month and we're on track to hit our Q3 targets.",
    "Your monthly account statement is now available in your online dashboard. No action is needed unless you notice any discrepancies.",
    "Hi, I had a question about row 14 in the budget spreadsheet, the numbers don't seem to match last quarter. Could you take a look?",
    "Thanks so much for your help yesterday with the presentation, it really made a difference during the client meeting.",
    "Here is the schedule for next week's workshop. Sessions start at 9 AM each day in the main hall.",
    "Just following up on our call earlier, I'll send the contract revisions by tomorrow morning as discussed.",
]

legit_urls = [
    "",  # many legit emails have no link at all
    "https://www.amazon.com/orders/58291",
    "https://github.com/notifications",
    "https://drive.google.com/shared/photos",
    "https://www.linkedin.com/feed",
    "https://accounts.google.com/calendar",
]


def make_phishing_email():
    subject = random.choice(phishing_subjects)
    sender = random.choice(phishing_senders)
    body_template = random.choice(phishing_bodies)
    url = random.choice(phishing_urls)
    body = body_template.format(url=url) if "{url}" in body_template else body_template + " " + url
    return subject, sender, body, 1


def make_legit_email():
    subject = random.choice(legit_subjects)
    sender = random.choice(legit_senders)
    body = random.choice(legit_bodies)
    url = random.choice(legit_urls)
    if url:
        body = body + " " + url
    return subject, sender, body, 0


def generate_dataset(n_per_class=300):
    rows = []
    for _ in range(n_per_class):
        rows.append(make_phishing_email())
    for _ in range(n_per_class):
        rows.append(make_legit_email())
    random.shuffle(rows)
    return rows


if __name__ == "__main__":
    rows = generate_dataset(n_per_class=300)
    with open("emails.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["subject", "sender", "body", "label"])
        writer.writerows(rows)
    print(f"Generated {len(rows)} emails -> emails.csv")
    print(f"  Phishing: {sum(1 for r in rows if r[3] == 1)}")
    print(f"  Safe:     {sum(1 for r in rows if r[3] == 0)}")
